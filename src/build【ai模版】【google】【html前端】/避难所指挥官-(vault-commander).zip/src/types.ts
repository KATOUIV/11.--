export type Gender = '男' | '女' | '未知';

export interface Trait {
  name: string;
  effect: string;
}

export interface Equipment {
  weapon: string;
  armor: string;
  accessory: string;
}

export interface Member {
  id: string;
  name: string;
  gender: Gender;
  combat: number;
  management: number;
  exploration: number;
  hp: number;
  maxHp: number;
  defense: number;
  status: string;
  loyalty: number;
  equipment: Equipment;
  traits: Trait[];
}

export interface VaultStats {
  power: number;
  water: number;
  food: number;
  caps: number;
  population: number;
  maxPopulation: number;
  happiness: number;
}

export interface Facility {
  id: string;
  name: string;
  level: number;
  type: string;
  status: '正常' | '损坏' | '升级中';
  output?: string;
}

export interface Policy {
  id: string;
  name: string;
  description: string;
  active: boolean;
}

export interface InventoryItem {
  id: string;
  name: string;
  quantity: number;
  type: '资源' | '武器' | '防具' | '杂项';
}

export interface DiplomacyRelation {
  faction: string;
  status: '盟友' | '中立' | '敌对';
  reputation: number;
}

export type GameTab = 'STAT' | 'INV' | 'DATA' | 'MAP' | 'RADIO';
// Mapping to user requirements:
// STAT -> 成员界面
// INV -> 仓库界面
// DATA -> 避难所管理/设施界面
// MAP -> 外交界面
// RADIO -> 体制政令界面
// LLM interaction is the main background/terminal.
