import { cn } from "@/lib/utils";
import { 
  Map, 
  ShieldAlert, 
  Users, 
  Building2, 
  Briefcase, 
  BrainCircuit, 
  UserPlus 
} from "lucide-react";

export type ModalType = 'plot' | 'faction' | 'bonds' | 'facilities' | 'inventory' | 'growth' | 'companions' | null;

interface SidebarProps {
  activeModal: ModalType;
  setActiveModal: (modal: ModalType) => void;
}

export function Sidebar({ activeModal, setActiveModal }: SidebarProps) {
  const navItems = [
    { id: 'plot', label: '主线棋局', icon: Map },
    { id: 'faction', label: '阵营状态', icon: ShieldAlert },
    { id: 'bonds', label: '派系羁绊', icon: Users },
    { id: 'facilities', label: '探案设施', icon: Building2 },
    { id: 'inventory', label: '仓库道具', icon: Briefcase },
    { id: 'growth', label: '个人成长', icon: BrainCircuit },
    { id: 'companions', label: '伙伴系统', icon: UserPlus },
  ] as const;

  return (
    <aside className="w-20 md:w-64 h-full glass-panel border-r border-white/5 flex flex-col items-center md:items-stretch py-6 transition-all duration-300 z-10">
      <div className="mb-10 px-4 flex justify-center md:justify-start items-center gap-3">
        <div className="w-10 h-10 rounded-full bg-sherlock-gold/20 flex items-center justify-center border border-sherlock-gold/50 shadow-[0_0_15px_rgba(184,134,11,0.3)]">
          <span className="font-serif text-sherlock-gold font-bold text-xl">S</span>
        </div>
        <h1 className="hidden md:block font-serif text-lg font-bold text-sherlock-text-primary tracking-widest">
          伦敦博弈场
        </h1>
      </div>

      <nav className="flex-1 w-full flex flex-col gap-2 px-2 md:px-4">
        {navItems.map((item) => {
          const Icon = item.icon;
          const isActive = activeModal === item.id;
          return (
            <button
              key={item.id}
              onClick={() => setActiveModal(isActive ? null : item.id)}
              className={cn(
                "group relative flex items-center gap-4 p-3 rounded-lg transition-all duration-300 overflow-hidden",
                isActive 
                  ? "bg-sherlock-gold/10 border border-sherlock-gold/30 shadow-[inset_0_0_20px_rgba(184,134,11,0.1)]" 
                  : "hover:bg-white/5 border border-transparent"
              )}
            >
              {/* Active Indicator Line */}
              {isActive && (
                <div className="absolute left-0 top-0 bottom-0 w-1 bg-sherlock-gold shadow-[0_0_10px_rgba(184,134,11,0.8)]" />
              )}
              
              <Icon 
                className={cn(
                  "w-6 h-6 transition-colors duration-300 shrink-0",
                  isActive ? "text-sherlock-gold" : "text-sherlock-gray group-hover:text-sherlock-text-primary"
                )} 
              />
              <span 
                className={cn(
                  "hidden md:block font-medium tracking-wide transition-colors duration-300",
                  isActive ? "text-sherlock-gold text-glow-gold" : "text-sherlock-text-secondary group-hover:text-sherlock-text-primary"
                )}
              >
                {item.label}
              </span>
            </button>
          );
        })}
      </nav>
    </aside>
  );
}
