import { cn } from "@/lib/utils";
import { X, Minus, Shield, Users, Building2, Briefcase, UserPlus, BrainCircuit, Map } from "lucide-react";
import { ModalType } from "./Sidebar";
import { Radar, RadarChart, PolarGrid, PolarAngleAxis, PolarRadiusAxis, ResponsiveContainer } from 'recharts';

interface ModalsProps {
  activeModal: ModalType;
  setActiveModal: (modal: ModalType) => void;
}

export function Modals({ activeModal, setActiveModal }: ModalsProps) {
  if (!activeModal) return null;

  return (
    <div className="absolute inset-0 z-50 flex items-center justify-center p-4 md:p-8 bg-black/60 backdrop-blur-sm transition-all duration-300">
      <div className="glass-panel-gold w-full max-w-5xl max-h-full rounded-xl flex flex-col overflow-hidden animate-in fade-in zoom-in-95 duration-200">
        {/* Modal Header */}
        <div className="flex items-center justify-between p-4 border-b border-sherlock-gold/20 bg-black/40">
          <div className="flex items-center gap-3">
            {getModalIcon(activeModal)}
            <h2 className="text-xl font-serif font-bold text-sherlock-gold tracking-widest">
              {getModalTitle(activeModal)}
            </h2>
          </div>
          <div className="flex items-center gap-2">
            <button className="p-1 text-sherlock-gray hover:text-sherlock-text-primary transition-colors">
              <Minus className="w-5 h-5" />
            </button>
            <button 
              onClick={() => setActiveModal(null)}
              className="p-1 text-sherlock-gray hover:text-sherlock-red transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Modal Content */}
        <div className="flex-1 overflow-y-auto custom-scrollbar p-6">
          {renderModalContent(activeModal)}
        </div>
      </div>
    </div>
  );
}

function getModalIcon(type: ModalType) {
  const className = "w-6 h-6 text-sherlock-gold";
  switch (type) {
    case 'plot': return <Map className={className} />;
    case 'faction': return <Shield className={className} />;
    case 'bonds': return <Users className={className} />;
    case 'facilities': return <Building2 className={className} />;
    case 'inventory': return <Briefcase className={className} />;
    case 'growth': return <BrainCircuit className={className} />;
    case 'companions': return <UserPlus className={className} />;
    default: return null;
  }
}

function getModalTitle(type: ModalType) {
  switch (type) {
    case 'plot': return '主线棋局 (MAIN PLOT)';
    case 'faction': return '阵营状态 (FACTION STATUS)';
    case 'bonds': return '派系羁绊 (FACTION BONDS)';
    case 'facilities': return '探案设施 (FACILITIES)';
    case 'inventory': return '仓库道具 (INVENTORY)';
    case 'growth': return '个人成长 (CHARACTER GROWTH)';
    case 'companions': return '伙伴系统 (COMPANIONS)';
    default: return '';
  }
}

function renderModalContent(type: ModalType) {
  switch (type) {
    case 'growth': return <GrowthModal />;
    case 'plot': return <PlotModal />;
    case 'faction': return <FactionModal />;
    case 'bonds': return <BondsModal />;
    case 'facilities': return <FacilitiesModal />;
    case 'inventory': return <InventoryModal />;
    case 'companions': return <CompanionsModal />;
    default: return null;
  }
}

// --- Specific Modal Contents ---

function GrowthModal() {
  const radarData = [
    { subject: '演绎力', A: 85, fullMark: 100 },
    { subject: '观察力', A: 90, fullMark: 100 },
    { subject: '沟通力', A: 65, fullMark: 100 },
    { subject: '应变力', A: 75, fullMark: 100 },
    { subject: '抗压性', A: 80, fullMark: 100 },
    { subject: '情报力', A: 70, fullMark: 100 },
    { subject: '气运值', A: 40, fullMark: 100 },
  ];

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
      {/* Basic Info & Radar */}
      <div className="space-y-6">
        <div className="glass-panel p-4 rounded-lg border border-white/5">
          <h3 className="text-sherlock-gold font-bold mb-4 border-b border-white/10 pb-2">基本档案</h3>
          <div className="grid grid-cols-2 gap-4 text-sm">
            <div><span className="text-sherlock-text-muted">代号:</span> <span className="text-sherlock-text-primary">咨询侦探</span></div>
            <div><span className="text-sherlock-text-muted">位置:</span> <span className="text-sherlock-text-primary">贝克街 221B</span></div>
            <div className="col-span-2">
              <span className="text-sherlock-text-muted">AP 恢复:</span> 
              <span className="text-sherlock-text-primary ml-2">每现实小时恢复 1 点，当前 12/20</span>
            </div>
          </div>
        </div>

        <div className="glass-panel p-4 rounded-lg border border-white/5 h-64 flex flex-col">
          <h3 className="text-sherlock-gold font-bold mb-2">七维属性雷达</h3>
          <div className="flex-1 w-full relative">
            <ResponsiveContainer width="100%" height="100%">
              <RadarChart cx="50%" cy="50%" outerRadius="70%" data={radarData}>
                <PolarGrid stroke="rgba(255,255,255,0.1)" />
                <PolarAngleAxis dataKey="subject" tick={{ fill: '#8A95A5', fontSize: 12 }} />
                <Radar name="侦探" dataKey="A" stroke="#B8860B" fill="#B8860B" fillOpacity={0.3} />
              </RadarChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>

      {/* Abilities & Traits */}
      <div className="space-y-6">
        <div className="glass-panel p-4 rounded-lg border border-white/5">
          <h3 className="text-sherlock-blue font-bold mb-4 border-b border-white/10 pb-2 text-glow-blue">辐射演绎超能力</h3>
          <div className="space-y-3">
            <AbilityCard name="思维殿堂·初阶" status="unlocked" desc="消耗 2 AP，在对话中强制获取一个隐藏线索。" />
            <AbilityCard name="微表情解析" status="unlocked" desc="被动：提升沟通力检定成功率 15%。" />
            <AbilityCard name="概率坍缩" status="locked" desc="未知。需要演绎力达到 95 解锁。" />
          </div>
        </div>

        <div className="glass-panel p-4 rounded-lg border border-white/5">
          <h3 className="text-sherlock-green font-bold mb-4 border-b border-white/10 pb-2">特质系统</h3>
          <div className="flex flex-wrap gap-2">
            <TraitBadge name="高智商反社会" type="initial" />
            <TraitBadge name="烟斗依赖" type="initial" />
            <TraitBadge name="华生的信任" type="bond" />
          </div>
        </div>
      </div>
    </div>
  );
}

function PlotModal() {
  return (
    <div className="space-y-6">
      <div className="glass-panel p-6 rounded-lg border border-sherlock-gold/30">
        <h3 className="text-lg font-bold text-sherlock-gold mb-2">双线博弈本质</h3>
        <p className="text-sm text-sherlock-text-secondary leading-relaxed">
          伦敦的地下世界正在被一股无形的力量重塑。莫里亚蒂的残党与新兴的犯罪辛迪加正在进行一场权力的交接。你不仅需要解开眼前的连环爆炸案，更要在苏格兰场、军情六处与地下黑帮之间寻找微妙的平衡。
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 relative pl-6 border-l-2 border-white/10 space-y-8">
          <TimelineNode 
            title="序章：血字的研究 (重置版)" 
            status="completed" 
            desc="劳里斯顿花园街的空屋里，一具没有伤痕的尸体。墙上的血字并非'RACHE'，而是'GAME'。"
          />
          <TimelineNode 
            title="第一章：塔桥危机" 
            status="active" 
            desc="莫里亚蒂的倒计时已经开始。大英博物馆的古埃及展区隐藏着第一个密码。"
          />
          <TimelineNode 
            title="第二章：？？？" 
            status="locked" 
            desc="完成第一章后解锁。"
          />
        </div>
        
        <div className="space-y-4">
          <div className="glass-panel p-4 rounded-lg">
            <h4 className="text-sm font-bold text-sherlock-text-primary mb-2">隐藏终极目标</h4>
            <div className="w-full h-2 bg-black/50 rounded-full overflow-hidden mb-1">
              <div className="h-full bg-sherlock-red w-[15%]" />
            </div>
            <p className="text-xs text-sherlock-text-muted text-right">15%</p>
          </div>
          
          <div className="glass-panel p-4 rounded-lg">
            <h4 className="text-sm font-bold text-sherlock-text-primary mb-2">伦敦世界现状</h4>
            <ul className="text-xs text-sherlock-text-secondary space-y-2">
              <li>• 泰晤士河水位异常上涨</li>
              <li>• 苏格兰场内部出现信任危机</li>
              <li>• 贝克街周边监视人员增加</li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  );
}

function FactionModal() {
  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="glass-panel p-5 rounded-lg border border-white/5 space-y-4">
          <h3 className="text-sherlock-gold font-bold border-b border-white/10 pb-2">核心生存资源</h3>
          <ResourceBar label="线索权重" value={65} color="bg-sherlock-blue" textColor="text-sherlock-blue" desc="影响推理的准确性与剧情分支解锁" />
          <ResourceBar label="警队话语权" value={30} color="bg-sherlock-red" textColor="text-sherlock-red" desc="调用官方资源的权限等级" />
          <ResourceBar label="情报覆盖度" value={45} color="bg-sherlock-gold" textColor="text-sherlock-gold" desc="提前预知危险与事件的能力" />
          <ResourceBar label="信任总值" value={80} color="bg-sherlock-green" textColor="text-sherlock-green" desc="各方势力对你的整体信任度" />
        </div>

        <div className="glass-panel p-5 rounded-lg border border-white/5 space-y-4">
          <h3 className="text-sherlock-gold font-bold border-b border-white/10 pb-2">探案环境指标</h3>
          <div className="grid grid-cols-3 gap-4 text-center">
            <div className="p-3 bg-black/30 rounded border border-white/5">
              <div className="text-2xl font-serif text-sherlock-blue mb-1">A-</div>
              <div className="text-xs text-sherlock-text-muted">演绎等级</div>
            </div>
            <div className="p-3 bg-black/30 rounded border border-white/5">
              <div className="text-2xl font-serif text-sherlock-red mb-1">低</div>
              <div className="text-xs text-sherlock-text-muted">警队公信力</div>
            </div>
            <div className="p-3 bg-black/30 rounded border border-white/5">
              <div className="text-2xl font-serif text-sherlock-green mb-1">高</div>
              <div className="text-xs text-sherlock-text-muted">团队士气</div>
            </div>
          </div>
          <p className="text-xs text-sherlock-text-secondary mt-4">
            当前环境增益：推理消耗 AP 减少 10%。<br/>
            当前环境减益：官方求助被拒绝概率增加 20%。
          </p>
        </div>
      </div>

      <div className="glass-panel p-5 rounded-lg border border-white/5">
        <h3 className="text-sherlock-gold font-bold border-b border-white/10 pb-2 mb-4">探案准则</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          <RuleSliderInteractive label="执法边界 (合法 vs 越界)" value={80} desc="极端越界将导致苏格兰场通缉。" />
          <RuleSliderInteractive label="信息管控 (公开 vs 隐瞒)" value={40} desc="过度隐瞒将降低华生信任度。" />
          <RuleSliderInteractive label="博弈底线 (仁慈 vs 冷酷)" value={60} desc="影响反派对你的评估与应对策略。" />
          <RuleSliderInteractive label="能力使用 (克制 vs 滥用)" value={30} desc="滥用超能力将加速理智值消耗。" />
        </div>
      </div>
    </div>
  );
}

function BondsModal() {
  const factions = [
    { name: '苏格兰场', align: 'neutral', value: 50, leader: '雷斯垂德探长', buff: '提供官方犯罪现场访问权' },
    { name: '贝克街小分队', align: 'friendly', value: 90, leader: '威金斯', buff: '每日提供免费底层情报' },
    { name: '军情六处', align: 'hostile', value: 20, leader: '迈克罗夫特·福尔摩斯', buff: '解锁国家级机密档案' },
    { name: '莫里亚蒂残党', align: 'hostile', value: 5, leader: '未知', buff: '解锁地下黑市交易权' },
    { name: '伦敦黑帮', align: 'neutral', value: 40, leader: '单身汉', buff: '提供暴力协助与走私渠道' },
    { name: '神秘学社', align: 'neutral', value: 10, leader: '艾琳·艾德勒', buff: '解锁超自然线索解析' },
  ];

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
      {factions.map((f, i) => (
        <div key={i} className="glass-panel p-4 rounded-lg border border-white/5 hover:border-sherlock-gold/30 transition-colors group cursor-pointer">
          <div className="flex justify-between items-start mb-2">
            <h4 className="font-bold text-sherlock-text-primary group-hover:text-sherlock-gold transition-colors">{f.name}</h4>
            <span className={cn(
              "text-[10px] px-2 py-0.5 rounded",
              f.align === 'friendly' ? "bg-sherlock-green/20 text-sherlock-green" :
              f.align === 'hostile' ? "bg-sherlock-red/20 text-sherlock-red" :
              "bg-sherlock-gray/20 text-sherlock-gray"
            )}>
              {f.align === 'friendly' ? '友善' : f.align === 'hostile' ? '敌对' : '中立'}
            </span>
          </div>
          <div className="w-full h-1.5 bg-black/50 rounded-full overflow-hidden mb-3">
            <div className={cn(
              "h-full",
              f.align === 'friendly' ? "bg-sherlock-green" :
              f.align === 'hostile' ? "bg-sherlock-red" :
              "bg-sherlock-gray"
            )} style={{ width: `${f.value}%` }} />
          </div>
          <div className="space-y-1 text-xs">
            <p><span className="text-sherlock-text-muted">核心领袖:</span> <span className="text-sherlock-text-secondary">{f.leader}</span></p>
            <p><span className="text-sherlock-text-muted">专属效果:</span> <span className="text-sherlock-text-secondary">{f.buff}</span></p>
          </div>
        </div>
      ))}
    </div>
  );
}

function FacilitiesModal() {
  const facilities = [
    { name: '化学实验室', level: 2, maxLevel: 5, desc: '用于分析微量物质与毒药。', effect: '线索解析速度 +20%' },
    { name: '档案库', level: 1, maxLevel: 3, desc: '存放旧案卷宗与剪报。', effect: '历史情报检索成功率 +10%' },
    { name: '伪装衣橱', level: 3, maxLevel: 5, desc: '包含各种身份的伪装道具。', effect: '潜入行动隐蔽度 +30%' },
    { name: '通讯监听站', level: 0, maxLevel: 3, desc: '截获伦敦电报与电话。', effect: '未解锁 (需要: 军情六处羁绊 40)' },
    { name: '暗房', level: 1, maxLevel: 2, desc: '冲洗照片与显影隐藏信息。', effect: '图像线索提取率 +15%' },
    { name: '思维冥想室', level: 0, maxLevel: 1, desc: '深度连接思维殿堂。', effect: '未解锁 (需要: 演绎力 90)' },
  ];

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
      {facilities.map((f, i) => (
        <div key={i} className={cn(
          "glass-panel p-4 rounded-lg border relative overflow-hidden",
          f.level > 0 ? "border-white/10" : "border-white/5 opacity-70"
        )}>
          {f.level === 0 && <div className="absolute inset-0 bg-black/40 z-10 flex items-center justify-center backdrop-blur-[1px]">
            <span className="text-sherlock-red text-sm font-bold bg-black/80 px-3 py-1 rounded border border-sherlock-red/30">未解锁</span>
          </div>}
          <div className="flex justify-between items-center mb-2">
            <h4 className="font-bold text-sherlock-gold">{f.name}</h4>
            <span className="text-xs font-mono text-sherlock-text-muted">Lv.{f.level}/{f.maxLevel}</span>
          </div>
          <p className="text-xs text-sherlock-text-secondary mb-2">{f.desc}</p>
          <p className="text-xs text-sherlock-blue bg-sherlock-blue/10 p-2 rounded border border-sherlock-blue/20">{f.effect}</p>
        </div>
      ))}
    </div>
  );
}

function InventoryModal() {
  const items = [
    { name: '放大镜', type: '探案', count: 1, desc: '基础探案工具，提升现场搜查效率。' },
    { name: '火漆密信', type: '剧情', count: 1, desc: '带有M标记的信件，散发着淡淡的苦杏仁味。' },
    { name: '左轮手枪', type: '生存', count: 1, desc: '装有6发子弹。最后的交涉手段。' },
    { name: '古柯碱溶液 (7%)', type: '增幅', count: 2, desc: '极度危险。瞬间回满AP，但会造成永久理智损伤。' },
    { name: '开锁工具', type: '探案', count: 3, desc: '用于开启普通门锁与保险箱。' },
    { name: '大英博物馆门票', type: '剧情', count: 1, desc: '今晚的特别展出邀请函。' },
  ];

  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
      {items.map((item, i) => (
        <div key={i} className="glass-panel p-4 rounded-lg border border-white/5 hover:border-white/20 transition-colors">
          <div className="flex justify-between items-start mb-2">
            <h4 className="font-bold text-sherlock-text-primary">{item.name}</h4>
            <span className={cn(
              "text-[10px] px-2 py-0.5 rounded border",
              item.type === '剧情' ? "bg-sherlock-gold/10 border-sherlock-gold/30 text-sherlock-gold" :
              item.type === '增幅' ? "bg-sherlock-blue/10 border-sherlock-blue/30 text-sherlock-blue" :
              item.type === '生存' ? "bg-sherlock-red/10 border-sherlock-red/30 text-sherlock-red" :
              "bg-white/5 border-white/10 text-sherlock-text-secondary"
            )}>{item.type}</span>
          </div>
          <p className="text-xs text-sherlock-text-secondary mb-3 h-10">{item.desc}</p>
          <div className="text-right text-xs font-mono text-sherlock-text-muted">
            持有数量: <span className="text-sherlock-text-primary">{item.count}</span>
          </div>
        </div>
      ))}
    </div>
  );
}

function CompanionsModal() {
  return (
    <div className="space-y-6">
      <div className="glass-panel p-6 rounded-lg border border-sherlock-gold/20 flex flex-col md:flex-row gap-6">
        <div className="w-32 h-32 bg-black/50 rounded-lg border border-white/10 flex items-center justify-center shrink-0">
          <span className="text-sherlock-text-muted text-sm">照片档案</span>
        </div>
        <div className="flex-1 space-y-4">
          <div className="flex justify-between items-start">
            <div>
              <h3 className="text-xl font-bold text-sherlock-gold">约翰·H·华生 医生</h3>
              <p className="text-sm text-sherlock-text-secondary">退役军医 / 传记作家 / 挚友</p>
            </div>
            <div className="text-right">
              <span className="text-xs text-sherlock-green bg-sherlock-green/10 px-2 py-1 rounded border border-sherlock-green/30">状态: 健康</span>
            </div>
          </div>
          
          <div>
            <div className="flex justify-between text-xs mb-1">
              <span className="text-sherlock-text-muted">羁绊等级: 生死之交</span>
              <span className="text-sherlock-gold font-mono">95/100</span>
            </div>
            <div className="w-full h-2 bg-black/50 rounded-full overflow-hidden">
              <div className="h-full bg-sherlock-gold w-[95%]" />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4 text-sm">
            <div><span className="text-sherlock-text-muted">专属特质:</span> <span className="text-sherlock-blue">战地急救</span> (战斗后恢复生命)</div>
            <div><span className="text-sherlock-text-muted">装备:</span> <span className="text-sherlock-text-primary">军用左轮, 医疗箱</span></div>
          </div>
        </div>
      </div>

      <div className="glass-panel p-6 rounded-lg border border-white/5 flex flex-col md:flex-row gap-6 opacity-70">
        <div className="w-32 h-32 bg-black/50 rounded-lg border border-white/10 flex items-center justify-center shrink-0">
          <span className="text-sherlock-text-muted text-sm">无档案</span>
        </div>
        <div className="flex-1 flex items-center justify-center">
          <p className="text-sherlock-text-muted">尚未解锁其他伙伴。推进主线剧情以结识新角色。</p>
        </div>
      </div>
    </div>
  );
}

// --- Helper Components ---

function AbilityCard({ name, status, desc }: { name: string, status: 'unlocked' | 'locked', desc: string }) {
  return (
    <div className={cn(
      "p-3 rounded border",
      status === 'unlocked' ? "bg-sherlock-blue/10 border-sherlock-blue/30" : "bg-white/5 border-white/10 opacity-60"
    )}>
      <div className="flex justify-between items-center mb-1">
        <span className={cn("font-bold text-sm", status === 'unlocked' ? "text-sherlock-blue" : "text-sherlock-text-muted")}>{name}</span>
        <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-black/50 text-sherlock-text-secondary">
          {status === 'unlocked' ? '已解锁' : '未解锁'}
        </span>
      </div>
      <p className="text-xs text-sherlock-text-secondary">{desc}</p>
    </div>
  );
}

function TraitBadge({ name, type }: { name: string, type: 'initial' | 'plot' | 'bond' }) {
  const colors = {
    initial: 'border-sherlock-gray text-sherlock-gray',
    plot: 'border-sherlock-gold text-sherlock-gold',
    bond: 'border-sherlock-green text-sherlock-green'
  };
  return (
    <span className={cn("px-2 py-1 text-xs border rounded-sm bg-black/40", colors[type])}>
      {name}
    </span>
  );
}

function TimelineNode({ title, status, desc }: { title: string, status: 'completed' | 'active' | 'locked', desc: string }) {
  return (
    <div className="relative">
      <div className={cn(
        "absolute -left-[31px] top-1 w-4 h-4 rounded-full border-2 bg-sherlock-bg",
        status === 'completed' ? "border-sherlock-green shadow-[0_0_10px_rgba(15,46,38,0.8)]" :
        status === 'active' ? "border-sherlock-gold shadow-[0_0_10px_rgba(184,134,11,0.8)]" :
        "border-sherlock-gray"
      )} />
      <h4 className={cn(
        "font-bold mb-1",
        status === 'completed' ? "text-sherlock-green" :
        status === 'active' ? "text-sherlock-gold" :
        "text-sherlock-text-muted"
      )}>{title}</h4>
      <p className="text-sm text-sherlock-text-secondary">{desc}</p>
    </div>
  );
}

function ResourceBar({ label, value, color, textColor, desc }: { label: string, value: number, color: string, textColor: string, desc: string }) {
  return (
    <div>
      <div className="flex justify-between items-end mb-1">
        <span className="text-sm text-sherlock-text-primary">{label}</span>
        <span className={cn("text-sm font-mono", textColor)}>{value}/100</span>
      </div>
      <div className="w-full h-2 bg-black/50 rounded-full overflow-hidden mb-1">
        <div className={cn("h-full", color)} style={{ width: `${value}%` }} />
      </div>
      <p className="text-[10px] text-sherlock-text-muted">{desc}</p>
    </div>
  );
}

function RuleSliderInteractive({ label, value, desc }: { label: string, value: number, desc: string }) {
  return (
    <div>
      <div className="flex justify-between items-center mb-2">
        <span className="text-sm text-sherlock-text-primary">{label}</span>
        <span className="text-xs font-mono text-sherlock-gold">{value}%</span>
      </div>
      <div className="relative h-2 bg-black/50 rounded-full border border-white/10 mb-2 cursor-pointer">
        <div className="absolute top-0 bottom-0 left-0 bg-sherlock-gold/50 rounded-full" style={{ width: `${value}%` }} />
        <div className="absolute top-1/2 -translate-y-1/2 w-4 h-4 rounded-full bg-sherlock-gold border-2 border-black shadow-[0_0_10px_rgba(184,134,11,0.8)]" style={{ left: `calc(${value}% - 8px)` }} />
      </div>
      <p className="text-[10px] text-sherlock-text-muted">{desc}</p>
    </div>
  );
}
