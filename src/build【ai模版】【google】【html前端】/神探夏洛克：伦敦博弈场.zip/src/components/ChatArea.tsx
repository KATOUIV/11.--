import { cn } from "@/lib/utils";
import { Send, History, Bookmark, Crosshair } from "lucide-react";
import { useState, useRef, useEffect } from "react";

interface Message {
  id: string;
  role: 'system' | 'user' | 'llm';
  content: string;
  type?: 'narrative' | 'clue' | 'check' | 'choice';
  metadata?: any;
}

export function ChatArea() {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: '1',
      role: 'system',
      content: '伦敦，1895年。浓雾笼罩着贝克街，煤气灯在湿漉漉的鹅卵石上投下摇曳的倒影。你站在221B的门前，手中紧紧攥着那封带有火漆印记的密信。',
      type: 'narrative'
    },
    {
      id: '2',
      role: 'llm',
      content: '“进来吧，门没锁。”一个低沉而富有磁性的声音从门内传出，伴随着小提琴弦被拨动的清脆声响。“你的脚步声比平时重了三分之一，心跳频率加快，左手袖口沾着泰晤士河畔特有的红泥。看来，苏格兰场又遇到了他们那可怜的智商无法处理的麻烦。”\n\n福尔摩斯放下小提琴，灰色的眼睛锐利地盯着你。“说吧，那封信里写了什么？”',
      type: 'narrative'
    },
    {
      id: '3',
      role: 'system',
      content: '【线索发现】获得关键物品：带有火漆印记的密信。线索权重 +5。',
      type: 'clue'
    },
    {
      id: '4',
      role: 'user',
      content: '我深吸一口气，将信件递给他。“是莫里亚蒂。他声称在伦敦塔桥下埋设了炸药，要求我们在午夜前解开他的谜题，否则……”',
    },
    {
      id: '5',
      role: 'system',
      content: '【沟通力检定】难度：困难 (75)。当前沟通力：80。检定成功！福尔摩斯的注意力被完全吸引。',
      type: 'check'
    },
    {
      id: '6',
      role: 'llm',
      content: '“莫里亚蒂……”福尔摩斯的眼神瞬间变得狂热，他猛地站起身，一把抓过信件。“游戏开始了！这不仅仅是炸药的问题，这是一个精心设计的棋局。他想测试我们的底线。”\n\n他转身看向你，眼中闪烁着危险的光芒。“我们现在有三个选择。直接去塔桥排爆，这最愚蠢；去苏格兰场调取监控，这最无聊；或者，去他信中提到的那个‘起点’——大英博物馆的古埃及展区。”',
      type: 'choice'
    }
  ]);

  const [inputValue, setInputValue] = useState('');
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const handleSend = () => {
    if (!inputValue.trim()) return;
    
    setMessages(prev => [...prev, {
      id: Date.now().toString(),
      role: 'user',
      content: inputValue
    }]);
    setInputValue('');
  };

  return (
    <main className="flex-1 flex flex-col relative overflow-hidden">
      {/* Chat History */}
      <div className="flex-1 overflow-y-auto custom-scrollbar p-6 space-y-6">
        {messages.map((msg) => (
          <MessageBubble key={msg.id} message={msg} />
        ))}
        <div ref={messagesEndRef} />
      </div>

      {/* Input Area */}
      <div className="p-6 pt-0">
        <div className="glass-panel rounded-xl p-2 flex flex-col gap-2 border border-white/10 focus-within:border-sherlock-gold/50 transition-colors">
          {/* Toolbar */}
          <div className="flex items-center gap-2 px-2 pb-2 border-b border-white/5">
            <button className="p-1.5 text-sherlock-text-muted hover:text-sherlock-gold transition-colors rounded" title="剧情回溯">
              <History className="w-4 h-4" />
            </button>
            <button className="p-1.5 text-sherlock-text-muted hover:text-sherlock-blue transition-colors rounded" title="线索标记">
              <Crosshair className="w-4 h-4" />
            </button>
            <button className="p-1.5 text-sherlock-text-muted hover:text-sherlock-text-primary transition-colors rounded" title="收藏抉择">
              <Bookmark className="w-4 h-4" />
            </button>
          </div>
          
          <div className="flex items-end gap-2">
            <textarea
              value={inputValue}
              onChange={(e) => setInputValue(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === 'Enter' && !e.shiftKey) {
                  e.preventDefault();
                  handleSend();
                }
              }}
              placeholder="输入你的行动或对话..."
              className="flex-1 bg-transparent border-none resize-none outline-none text-sherlock-text-primary placeholder:text-sherlock-text-muted p-2 max-h-32 min-h-[44px] custom-scrollbar"
              rows={1}
            />
            <button 
              onClick={handleSend}
              disabled={!inputValue.trim()}
              className="p-3 bg-sherlock-gold/20 text-sherlock-gold rounded-lg hover:bg-sherlock-gold/30 disabled:opacity-50 disabled:cursor-not-allowed transition-colors border border-sherlock-gold/30"
            >
              <Send className="w-5 h-5" />
            </button>
          </div>
        </div>
      </div>
    </main>
  );
}

function MessageBubble({ message }: { message: Message }) {
  if (message.role === 'system') {
    return (
      <div className="flex justify-center my-4">
        <div className={cn(
          "px-4 py-2 rounded-full text-xs font-medium border backdrop-blur-sm",
          message.type === 'clue' ? "bg-sherlock-blue/10 border-sherlock-blue/30 text-sherlock-blue" :
          message.type === 'check' ? "bg-sherlock-green/10 border-sherlock-green/30 text-sherlock-green" :
          "bg-white/5 border-white/10 text-sherlock-text-secondary"
        )}>
          {message.content}
        </div>
      </div>
    );
  }

  const isUser = message.role === 'user';

  return (
    <div className={cn("flex w-full", isUser ? "justify-end" : "justify-start")}>
      <div className={cn(
        "max-w-[80%] rounded-2xl p-4 glass-panel relative group",
        isUser ? "bg-sherlock-gold/10 border-sherlock-gold/20 rounded-tr-sm" : "bg-black/40 border-white/10 rounded-tl-sm"
      )}>
        <p className="text-sm leading-relaxed text-sherlock-text-primary whitespace-pre-wrap">
          {message.content}
        </p>
        
        {message.type === 'choice' && (
          <div className="mt-4 flex flex-col gap-2">
            <ChoiceButton text="前往大英博物馆古埃及展区" type="primary" />
            <ChoiceButton text="前往伦敦塔桥排爆" type="danger" />
            <ChoiceButton text="前往苏格兰场调取监控" type="neutral" />
          </div>
        )}
      </div>
    </div>
  );
}

function ChoiceButton({ text, type }: { text: string, type: 'primary' | 'danger' | 'neutral' }) {
  return (
    <button className={cn(
      "text-left px-4 py-3 rounded-lg text-sm transition-all duration-300 border flex items-center justify-between group",
      type === 'primary' ? "bg-sherlock-gold/10 border-sherlock-gold/30 hover:bg-sherlock-gold/20 text-sherlock-gold" :
      type === 'danger' ? "bg-sherlock-red/10 border-sherlock-red/30 hover:bg-sherlock-red/20 text-sherlock-red" :
      "bg-white/5 border-white/10 hover:bg-white/10 text-sherlock-text-secondary hover:text-sherlock-text-primary"
    )}>
      <span>{text}</span>
      <span className="opacity-0 group-hover:opacity-100 transition-opacity text-xs font-mono">
        -1 AP
      </span>
    </button>
  );
}
