import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Terminal as TerminalIcon, 
  Users, 
  Settings, 
  Shield, 
  Package, 
  Zap, 
  Globe, 
  FileText,
  Activity,
  Map as MapIcon,
  Radio,
  ChevronRight,
  Send,
  Heart,
  Sword,
  Search,
  Box
} from 'lucide-react';
import { GoogleGenAI } from "@google/genai";
import { 
  Member, 
  VaultStats, 
  Facility, 
  Policy, 
  InventoryItem, 
  DiplomacyRelation,
  GameTab 
} from './types';

// Initial Mock Data
const INITIAL_MEMBERS: Member[] = [
  {
    id: '1',
    name: '阿尔伯特·沃克',
    gender: '男',
    combat: 8,
    management: 4,
    exploration: 7,
    hp: 100,
    maxHp: 100,
    defense: 15,
    status: '健康',
    loyalty: 85,
    equipment: { weapon: '10mm 手枪', armor: '避难所连身衣', accessory: '无' },
    traits: [{ name: '神枪手', effect: '远程武器精准度 +10%' }, { name: '坚韧', effect: '生命上限 +10' }]
  },
  {
    id: '2',
    name: '萨拉·康纳',
    gender: '女',
    combat: 9,
    management: 3,
    exploration: 6,
    hp: 90,
    maxHp: 90,
    defense: 12,
    status: '疲劳',
    loyalty: 92,
    equipment: { weapon: '战斗散弹枪', armor: '皮甲', accessory: '战术护目镜' },
    traits: [{ name: '生存专家', effect: '探索资源获取 +20%' }]
  }
];

const INITIAL_STATS: VaultStats = {
  power: 85,
  water: 72,
  food: 64,
  caps: 1250,
  population: 24,
  maxPopulation: 50,
  happiness: 78
};

const INITIAL_FACILITIES: Facility[] = [
  { id: '1', name: '核能发电机', level: 2, type: '电力', status: '正常', output: '50/h' },
  { id: '2', name: '水净化系统', level: 1, type: '水', status: '正常', output: '30/h' },
  { id: '3', name: '水培农场', level: 1, type: '食物', status: '正常', output: '25/h' }
];

const INITIAL_POLICIES: Policy[] = [
  { id: '1', name: '配给制', description: '减少食物和水消耗，但降低幸福度。', active: false },
  { id: '2', name: '强制劳动', description: '提高生产效率，但大幅降低忠诚度。', active: false },
  { id: '3', name: '避难所开放日', description: '吸引废土居民，提高幸福度。', active: true }
];

const INITIAL_INVENTORY: InventoryItem[] = [
  { id: '1', name: '10mm 子弹', quantity: 150, type: '资源' },
  { id: '2', name: '治疗针', quantity: 12, type: '资源' },
  { id: '3', name: '动力甲核心', quantity: 2, type: '杂项' }
];

const INITIAL_DIPLOMACY: DiplomacyRelation[] = [
  { faction: '钢铁兄弟会', status: '中立', reputation: 50 },
  { faction: '学院', status: '敌对', reputation: 10 },
  { faction: '义勇军', status: '盟友', reputation: 90 }
];

export default function App() {
  const [activeTab, setActiveTab] = useState<GameTab>('STAT');
  const [members, setMembers] = useState<Member[]>(INITIAL_MEMBERS);
  const [stats, setStats] = useState<VaultStats>(INITIAL_STATS);
  const [facilities, setFacilities] = useState<Facility[]>(INITIAL_FACILITIES);
  const [policies, setPolicies] = useState<Policy[]>(INITIAL_POLICIES);
  const [inventory, setInventory] = useState<InventoryItem[]>(INITIAL_INVENTORY);
  const [diplomacy, setDiplomacy] = useState<DiplomacyRelation[]>(INITIAL_DIPLOMACY);
  
  // LLM Interaction State
  const [chatInput, setChatInput] = useState('');
  const [chatHistory, setChatHistory] = useState<{ role: 'user' | 'ai', text: string }[]>([
    { role: 'ai', text: '欢迎回来，指挥官。避难所 101 系统已就绪。请指示。' }
  ]);
  const [isTyping, setIsTyping] = useState(false);
  const chatEndRef = useRef<HTMLDivElement>(null);

  const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });

  useEffect(() => {
    chatEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [chatHistory]);

  const handleSendMessage = async () => {
    if (!chatInput.trim()) return;

    const userMsg = chatInput;
    setChatInput('');
    setChatHistory(prev => [...prev, { role: 'user', text: userMsg }]);
    setIsTyping(true);

    try {
      const response = await ai.models.generateContent({
        model: "gemini-3-flash-preview",
        contents: [
          { role: 'user', parts: [{ text: `你是一个末世避难所的AI管家。当前避难所状态：电力${stats.power}%, 水${stats.water}%, 食物${stats.food}%, 人口${stats.population}。请以Pip-Boy终端的语气回应指挥官：${userMsg}` }] }
        ],
        config: {
          systemInstruction: "你是一个名为'Vault-OS'的AI。你的语气应该是冷冰冰的、高效的、偶尔带点黑色幽默的。你必须使用中文。保持简短。不要使用表情符号。"
        }
      });

      const aiText = response.text || '系统错误：无法连接到中央处理器。';
      setChatHistory(prev => [...prev, { role: 'ai', text: aiText }]);
    } catch (error) {
      console.error('AI Error:', error);
      setChatHistory(prev => [...prev, { role: 'ai', text: '警告：通信链路中断。' }]);
    } finally {
      setIsTyping(false);
    }
  };

  const renderTabContent = () => {
    switch (activeTab) {
      case 'STAT':
        return (
          <div className="flex flex-col h-full overflow-hidden">
            <h2 className="text-2xl mb-4 pip-glow flex items-center gap-2">
              <Users size={24} /> 成员管理
            </h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 overflow-y-auto pip-scrollbar pr-2">
              {members.map(member => (
                <div key={member.id} className="pip-panel border-pip-green/50 hover:border-pip-green transition-colors">
                  <div className="flex justify-between items-start mb-2">
                    <div>
                      <h3 className="text-xl font-bold">{member.name}</h3>
                      <p className="text-xs opacity-70">{member.gender} | {member.status}</p>
                    </div>
                    <div className="text-right">
                      <p className="text-sm">忠诚度: {member.loyalty}%</p>
                      <p className="text-sm">防御: {member.defense}</p>
                    </div>
                  </div>
                  
                  <div className="space-y-2 mb-3">
                    <div className="flex items-center gap-2">
                      <Heart size={14} className="text-red-500" />
                      <div className="flex-1 h-2 bg-pip-green-dim rounded-full overflow-hidden">
                        <div className="h-full bg-pip-green" style={{ width: `${(member.hp / member.maxHp) * 100}%` }}></div>
                      </div>
                      <span className="text-xs">{member.hp}/{member.maxHp}</span>
                    </div>
                  </div>

                  <div className="grid grid-cols-3 gap-2 text-center text-xs mb-3">
                    <div className="pip-panel p-1">武力: {member.combat}</div>
                    <div className="pip-panel p-1">管理: {member.management}</div>
                    <div className="pip-panel p-1">探索: {member.exploration}</div>
                  </div>

                  <div className="text-xs space-y-1">
                    <p className="font-bold border-b border-pip-green/20 pb-1 mb-1">装备</p>
                    <p>武器: {member.equipment.weapon}</p>
                    <p>防具: {member.equipment.armor}</p>
                    <p>饰品: {member.equipment.accessory}</p>
                  </div>

                  <div className="mt-3">
                    <p className="text-xs font-bold border-b border-pip-green/20 pb-1 mb-1">特质</p>
                    <div className="flex flex-wrap gap-1">
                      {member.traits.map((trait, i) => (
                        <span key={i} className="text-[10px] bg-pip-green/10 px-1 border border-pip-green/30" title={trait.effect}>
                          {trait.name}
                        </span>
                      ))}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        );
      case 'INV':
        return (
          <div className="flex flex-col h-full">
            <h2 className="text-2xl mb-4 pip-glow flex items-center gap-2">
              <Package size={24} /> 仓库库存
            </h2>
            <div className="pip-panel flex-1 overflow-y-auto pip-scrollbar">
              <table className="w-full text-left">
                <thead>
                  <tr className="border-b border-pip-green/30 text-sm">
                    <th className="pb-2">名称</th>
                    <th className="pb-2">类型</th>
                    <th className="pb-2 text-right">数量</th>
                  </tr>
                </thead>
                <tbody>
                  {inventory.map(item => (
                    <tr key={item.id} className="border-b border-pip-green/10 hover:bg-pip-green/5 transition-colors">
                      <td className="py-2">{item.name}</td>
                      <td className="py-2 text-xs opacity-70">{item.type}</td>
                      <td className="py-2 text-right font-bold">{item.quantity}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        );
      case 'DATA':
        return (
          <div className="flex flex-col h-full gap-4">
            <div className="flex-1">
              <h2 className="text-2xl mb-4 pip-glow flex items-center gap-2">
                <Zap size={24} /> 设施状态
              </h2>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                {facilities.map(f => (
                  <div key={f.id} className="pip-panel">
                    <div className="flex justify-between items-center mb-2">
                      <h3 className="font-bold">{f.name}</h3>
                      <span className={`text-[10px] px-1 border ${f.status === '正常' ? 'border-pip-green text-pip-green' : 'border-yellow-500 text-yellow-500'}`}>
                        {f.status}
                      </span>
                    </div>
                    <p className="text-xs">等级: {f.level}</p>
                    <p className="text-xs">类型: {f.type}</p>
                    {f.output && <p className="text-xs text-pip-green/70">产出: {f.output}</p>}
                  </div>
                ))}
              </div>
            </div>
            <div className="flex-1">
              <h2 className="text-2xl mb-4 pip-glow flex items-center gap-2">
                <Activity size={24} /> 避难所概况
              </h2>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                <div className="pip-panel text-center">
                  <p className="text-xs opacity-70">人口</p>
                  <p className="text-xl font-bold">{stats.population}/{stats.maxPopulation}</p>
                </div>
                <div className="pip-panel text-center">
                  <p className="text-xs opacity-70">幸福度</p>
                  <p className="text-xl font-bold">{stats.happiness}%</p>
                </div>
                <div className="pip-panel text-center">
                  <p className="text-xs opacity-70">瓶盖</p>
                  <p className="text-xl font-bold">{stats.caps}</p>
                </div>
                <div className="pip-panel text-center">
                  <p className="text-xs opacity-70">防御等级</p>
                  <p className="text-xl font-bold">42</p>
                </div>
              </div>
            </div>
          </div>
        );
      case 'MAP':
        return (
          <div className="flex flex-col h-full">
            <h2 className="text-2xl mb-4 pip-glow flex items-center gap-2">
              <Globe size={24} /> 外交关系
            </h2>
            <div className="grid grid-cols-1 gap-4">
              {diplomacy.map((d, i) => (
                <div key={i} className="pip-panel flex justify-between items-center">
                  <div>
                    <h3 className="text-lg font-bold">{d.faction}</h3>
                    <p className="text-xs opacity-70">声望: {d.reputation}/100</p>
                  </div>
                  <div className={`px-4 py-1 border-2 font-bold ${
                    d.status === '盟友' ? 'border-pip-green text-pip-green' :
                    d.status === '敌对' ? 'border-red-500 text-red-500' :
                    'border-yellow-500 text-yellow-500'
                  }`}>
                    {d.status}
                  </div>
                </div>
              ))}
            </div>
            <div className="mt-8 pip-panel bg-pip-green/5 border-dashed border-pip-green/30 flex items-center justify-center h-32">
              <p className="text-pip-green/50 italic flex items-center gap-2">
                <MapIcon size={16} /> 外部地图扫描中...
              </p>
            </div>
          </div>
        );
      case 'RADIO':
        return (
          <div className="flex flex-col h-full">
            <h2 className="text-2xl mb-4 pip-glow flex items-center gap-2">
              <Radio size={24} /> 体制政令
            </h2>
            <div className="space-y-4">
              {policies.map(p => (
                <div key={p.id} className={`pip-panel transition-all ${p.active ? 'border-pip-green bg-pip-green/10' : 'border-pip-green/20'}`}>
                  <div className="flex justify-between items-center mb-2">
                    <h3 className="text-lg font-bold">{p.name}</h3>
                    <button 
                      onClick={() => setPolicies(prev => prev.map(pol => pol.id === p.id ? { ...pol, active: !pol.active } : pol))}
                      className={`pip-btn text-xs py-1 ${p.active ? 'active' : ''}`}
                    >
                      {p.active ? '已启用' : '启用'}
                    </button>
                  </div>
                  <p className="text-sm opacity-80">{p.description}</p>
                </div>
              ))}
            </div>
          </div>
        );
      default:
        return null;
    }
  };

  return (
    <div className="crt-screen w-full h-full flex flex-col p-4 md:p-8 select-none">
      <div className="scanline"></div>
      
      {/* Top Header Stats */}
      <div className="flex flex-wrap justify-between items-center mb-6 border-b-2 border-pip-green pb-4">
        <div className="flex items-center gap-6">
          <h1 className="text-3xl font-black tracking-tighter pip-glow">VAULT-OS v1.0.1</h1>
          <div className="hidden lg:flex items-center gap-4 text-xs">
            <div className="flex items-center gap-1"><Zap size={14} /> 电力: {stats.power}%</div>
            <div className="flex items-center gap-1"><Activity size={14} /> 水源: {stats.water}%</div>
            <div className="flex items-center gap-1"><Users size={14} /> 食物: {stats.food}%</div>
          </div>
        </div>
        <div className="text-right">
          <p className="text-xs opacity-70">当前时间: 2077.10.23</p>
          <p className="text-sm font-bold">避难所 101 - 监督者模式</p>
        </div>
      </div>

      {/* Main Content Area */}
      <div className="flex-1 grid grid-cols-1 lg:grid-cols-12 gap-6 overflow-hidden">
        
        {/* Left Panel: LLM Interaction Terminal */}
        <div className="lg:col-span-5 flex flex-col h-full overflow-hidden border-r border-pip-green/30 pr-6">
          <div className="flex items-center gap-2 mb-4 text-pip-green/70">
            <TerminalIcon size={18} />
            <span className="text-sm tracking-widest uppercase">终端交互</span>
          </div>
          
          <div className="flex-1 overflow-y-auto pip-scrollbar mb-4 space-y-4 pr-2">
            {chatHistory.map((msg, i) => (
              <motion.div 
                key={i}
                initial={{ opacity: 0, x: -10 }}
                animate={{ opacity: 1, x: 0 }}
                className={`flex flex-col ${msg.role === 'user' ? 'items-end' : 'items-start'}`}
              >
                <div className={`max-w-[90%] p-3 rounded-sm border ${
                  msg.role === 'user' 
                    ? 'border-pip-green bg-pip-green/10 text-pip-green' 
                    : 'border-pip-green/30 bg-pip-bg text-pip-green'
                }`}>
                  <p className="text-sm leading-relaxed whitespace-pre-wrap">{msg.text}</p>
                </div>
                <span className="text-[10px] opacity-40 mt-1">
                  {msg.role === 'user' ? '指挥官' : 'VAULT-OS'}
                </span>
              </motion.div>
            ))}
            {isTyping && (
              <div className="flex gap-1 items-center text-pip-green/50">
                <span className="animate-pulse">系统处理中...</span>
              </div>
            )}
            <div ref={chatEndRef} />
          </div>

          <div className="relative">
            <input 
              type="text"
              value={chatInput}
              onChange={(e) => setChatInput(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && handleSendMessage()}
              placeholder="输入指令..."
              className="w-full bg-pip-bg border-2 border-pip-green p-3 pr-12 text-pip-green placeholder:text-pip-green/30 focus:outline-none focus:ring-2 focus:ring-pip-green/50"
            />
            <button 
              onClick={handleSendMessage}
              className="absolute right-2 top-1/2 -translate-y-1/2 p-2 text-pip-green hover:bg-pip-green hover:text-pip-bg transition-colors"
            >
              <Send size={20} />
            </button>
          </div>
        </div>

        {/* Right Panel: Functional Interfaces */}
        <div className="lg:col-span-7 flex flex-col h-full overflow-hidden">
          {/* Navigation Tabs */}
          <div className="flex flex-wrap gap-2 mb-6">
            <button 
              onClick={() => setActiveTab('STAT')}
              className={`pip-btn flex items-center gap-2 ${activeTab === 'STAT' ? 'active' : ''}`}
            >
              <Users size={16} /> 成员
            </button>
            <button 
              onClick={() => setActiveTab('INV')}
              className={`pip-btn flex items-center gap-2 ${activeTab === 'INV' ? 'active' : ''}`}
            >
              <Package size={16} /> 仓库
            </button>
            <button 
              onClick={() => setActiveTab('DATA')}
              className={`pip-btn flex items-center gap-2 ${activeTab === 'DATA' ? 'active' : ''}`}
            >
              <Zap size={16} /> 设施
            </button>
            <button 
              onClick={() => setActiveTab('MAP')}
              className={`pip-btn flex items-center gap-2 ${activeTab === 'MAP' ? 'active' : ''}`}
            >
              <Globe size={16} /> 外交
            </button>
            <button 
              onClick={() => setActiveTab('RADIO')}
              className={`pip-btn flex items-center gap-2 ${activeTab === 'RADIO' ? 'active' : ''}`}
            >
              <Radio size={16} /> 政令
            </button>
          </div>

          {/* Tab Content with Animation */}
          <div className="flex-1 overflow-hidden">
            <AnimatePresence mode="wait">
              <motion.div
                key={activeTab}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -10 }}
                transition={{ duration: 0.2 }}
                className="h-full"
              >
                {renderTabContent()}
              </motion.div>
            </AnimatePresence>
          </div>
        </div>
      </div>

      {/* Footer Status Bar */}
      <div className="mt-6 border-t border-pip-green/30 pt-4 flex justify-between items-center text-[10px] tracking-widest uppercase opacity-60">
        <div className="flex gap-4">
          <span>CPU: 正常</span>
          <span>内存: 4096KB</span>
          <span>网络: 已加密</span>
        </div>
        <div className="flex items-center gap-2">
          <div className="w-2 h-2 bg-pip-green rounded-full animate-pulse"></div>
          <span>系统在线</span>
        </div>
      </div>
    </div>
  );
}
