import { useState } from "react";
import { Sidebar, ModalType } from "./components/Sidebar";
import { Topbar } from "./components/Topbar";
import { ChatArea } from "./components/ChatArea";
import { BottomBar } from "./components/BottomBar";
import { Modals } from "./components/Modals";

export default function App() {
  const [activeModal, setActiveModal] = useState<ModalType>(null);

  return (
    <div className="flex h-screen w-full bg-sherlock-bg text-sherlock-text-primary crt-scanlines overflow-hidden">
      {/* Background overlay for extra atmosphere */}
      <div className="absolute inset-0 bg-[url('https://picsum.photos/seed/london-fog/1920/1080?grayscale&blur=2')] opacity-10 mix-blend-overlay pointer-events-none" />
      
      <Sidebar activeModal={activeModal} setActiveModal={setActiveModal} />
      
      <div className="flex-1 flex flex-col min-w-0 relative">
        <Topbar />
        <ChatArea />
        <BottomBar />
      </div>

      <Modals activeModal={activeModal} setActiveModal={setActiveModal} />
    </div>
  );
}
