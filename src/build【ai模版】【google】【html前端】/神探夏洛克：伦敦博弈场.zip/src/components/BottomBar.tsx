import { cn } from "@/lib/utils";
import { Zap, Scale, Fingerprint, MessageSquareWarning } from "lucide-react";

export function BottomBar() {
  return (
    <footer className="h-20 glass-panel border-t border-white/5 flex items-center px-6 gap-8 z-10">
      {/* AP Section */}
      <div className="flex flex-col gap-1 min-w-[120px]">
        <div className="flex justify-between items-center">
          <span className="text-xs text-sherlock-text-muted flex items-center gap-1">
            <Zap className="w-3 h-3 text-sherlock-gold" />
            行动点数 (AP)
          </span>
          <span className="text-sm font-mono text-sherlock-gold">12/20</span>
        </div>
        <div className="flex gap-1">
          {Array.from({ length: 20 }).map((_, i) => (
            <div 
              key={i} 
              className={cn(
                "h-2 flex-1 rounded-sm",
                i < 12 ? "bg-sherlock-gold shadow-[0_0_5px_rgba(184,134,11,0.5)]" : "bg-white/10"
              )}
            />
          ))}
        </div>
      </div>

      <div className="w-px h-10 bg-white/10" />

      {/* Quick Stats */}
      <div className="flex-1 flex items-center gap-8">
        <QuickStat icon={Fingerprint} label="线索权重" value={65} color="text-sherlock-blue" barColor="bg-sherlock-blue" />
        <QuickStat icon={MessageSquareWarning} label="警队话语权" value={30} color="text-sherlock-red" barColor="bg-sherlock-red" />
      </div>

      <div className="w-px h-10 bg-white/10" />

      {/* Rules Sliders Preview */}
      <div className="flex items-center gap-4">
        <RuleSlider label="执法边界" value={80} type="danger" />
        <RuleSlider label="信息管控" value={40} type="safe" />
      </div>
    </footer>
  );
}

function QuickStat({ icon: Icon, label, value, color, barColor }: { icon: any, label: string, value: number, color: string, barColor: string }) {
  return (
    <div className="flex-1 max-w-[200px] flex flex-col gap-1 cursor-pointer group">
      <div className="flex justify-between items-center">
        <span className="text-xs text-sherlock-text-secondary flex items-center gap-1 group-hover:text-sherlock-text-primary transition-colors">
          <Icon className={cn("w-3 h-3", color)} />
          {label}
        </span>
        <span className={cn("text-xs font-mono", color)}>{value}%</span>
      </div>
      <div className="w-full h-1.5 bg-black/50 rounded-full overflow-hidden border border-white/5">
        <div className={cn("h-full transition-all duration-500", barColor)} style={{ width: `${value}%` }} />
      </div>
    </div>
  );
}

function RuleSlider({ label, value, type }: { label: string, value: number, type: 'danger' | 'safe' }) {
  const color = type === 'danger' ? 'bg-sherlock-red' : 'bg-sherlock-green';
  const textColor = type === 'danger' ? 'text-sherlock-red' : 'text-sherlock-green';
  
  return (
    <div className="flex flex-col gap-1 w-24 cursor-pointer group">
      <span className="text-[10px] text-sherlock-text-muted text-center group-hover:text-sherlock-text-primary transition-colors">{label}</span>
      <div className="relative h-2 bg-black/50 rounded-full border border-white/10">
        <div className={cn("absolute top-0 bottom-0 left-0 rounded-full opacity-50", color)} style={{ width: `${value}%` }} />
        <div 
          className={cn("absolute top-1/2 -translate-y-1/2 w-3 h-3 rounded-full border border-white shadow-[0_0_5px_rgba(255,255,255,0.5)]", color)} 
          style={{ left: `calc(${value}% - 6px)` }} 
        />
      </div>
    </div>
  );
}
