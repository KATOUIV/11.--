import { cn } from "@/lib/utils";
import { Clock, Shield, EyeOff, Activity } from "lucide-react";
import { useEffect, useState } from "react";

export function Topbar() {
  const [time, setTime] = useState(new Date());

  useEffect(() => {
    const timer = setInterval(() => setTime(new Date()), 1000);
    return () => clearInterval(timer);
  }, []);

  const formattedDate = time.toLocaleDateString('zh-CN', { year: 'numeric', month: '2-digit', day: '2-digit' });
  const formattedTime = time.toLocaleTimeString('zh-CN', { hour12: false });

  return (
    <header className="h-16 glass-panel border-b border-white/5 flex items-center justify-between px-6 z-10">
      <div className="flex items-center gap-6">
        <div className="flex items-center gap-2 text-sherlock-gold font-mono text-sm">
          <Clock className="w-4 h-4" />
          <span className="tracking-wider">{formattedDate} {formattedTime}</span>
        </div>
        
        <div className="hidden md:flex items-center gap-3">
          <span className="text-xs text-sherlock-text-muted uppercase tracking-widest">主线进度</span>
          <div className="w-32 h-1.5 bg-black/50 rounded-full overflow-hidden border border-white/10">
            <div className="h-full bg-sherlock-blue shadow-[0_0_10px_rgba(30,92,140,0.8)] w-[35%]" />
          </div>
          <span className="text-xs text-sherlock-blue font-mono">35%</span>
        </div>
      </div>

      <div className="flex items-center gap-6">
        <StatusIndicator 
          icon={Activity} 
          label="棋局掌控力" 
          value={78} 
          color="text-sherlock-gold" 
          barColor="bg-sherlock-gold" 
        />
        <StatusIndicator 
          icon={Shield} 
          label="安保防护" 
          value={92} 
          color="text-sherlock-green" 
          barColor="bg-sherlock-green" 
        />
        <StatusIndicator 
          icon={EyeOff} 
          label="行动隐蔽度" 
          value={45} 
          color="text-sherlock-red" 
          barColor="bg-sherlock-red" 
        />
      </div>
    </header>
  );
}

function StatusIndicator({ icon: Icon, label, value, color, barColor }: { icon: any, label: string, value: number, color: string, barColor: string }) {
  return (
    <div className="group relative flex items-center gap-2 cursor-help">
      <Icon className={cn("w-4 h-4", color)} />
      <div className="hidden lg:flex flex-col gap-1">
        <div className="flex justify-between items-center w-24">
          <span className="text-[10px] text-sherlock-text-muted">{label}</span>
          <span className={cn("text-xs font-mono", color)}>{value}%</span>
        </div>
        <div className="w-24 h-1 bg-black/50 rounded-full overflow-hidden">
          <div className={cn("h-full", barColor)} style={{ width: `${value}%` }} />
        </div>
      </div>
      
      {/* Tooltip */}
      <div className="absolute top-full right-0 mt-2 w-48 p-3 glass-panel rounded-lg opacity-0 invisible group-hover:opacity-100 group-hover:visible transition-all duration-200 z-50">
        <h4 className={cn("text-sm font-bold mb-1", color)}>{label}</h4>
        <p className="text-xs text-sherlock-text-secondary">当前数值: {value}/100</p>
        <p className="text-xs text-sherlock-text-muted mt-1">影响相关检定成功率与剧情走向。</p>
      </div>
    </div>
  );
}
